function f(aa, b)
  return {
    aa,
    bb,
  }
end

return { f = f }
