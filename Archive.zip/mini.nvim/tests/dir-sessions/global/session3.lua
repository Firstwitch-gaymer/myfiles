-- This will be sourced as Lua code (read `:h -S` and `:h source`)
_G.session_file = 'tests/dir-sessions/global/session3.lua'
