return { ['snippets/lua.lua'] = { prefix = 'b', body = 'B=$1' } }
