return { ['snippets/nested/lua.lua'] = { prefix = 'h', body = 'H=$1' } }
