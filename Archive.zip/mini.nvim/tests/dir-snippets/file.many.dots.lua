return { { prefix = 'a', body = 'A=$1' } }
