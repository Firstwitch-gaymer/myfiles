return { ['subdir/snippets/lua/snips.lua'] = { prefix = 'd', body = 'D=$1' } }
