return {
  name_a = { prefix = 'lua_a', body = 'LUA_A=$1', desc = 'Desc LUA_A' },
  name_b = { prefix = 'lua_b', body = 'LUA_B=$1', description = 'Desc LUA_B' },
  name_c = { prefix = nil, body = 'LUA_C=$1', desc = nil },
  dupl1 = { prefix = 'd', body = 'D1=$1', desc = nil },
  dupl2 = { prefix = 'd', body = nil, desc = 'Dupl2' },

  problem_a = { prefix = 1, desc = 'Not snippet data #1' },
  problem_b = 2,
}
