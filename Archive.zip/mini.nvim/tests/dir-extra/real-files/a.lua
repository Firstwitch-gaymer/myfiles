local a = 1
local t = {
  x = math.max(a, 2),
  y = math.min(a, 2),
}
