---@text This is `@text` section.
--- It has multiple lines.
---@text This is another section in the same block.

---@text This is another block with single `@text` section.
