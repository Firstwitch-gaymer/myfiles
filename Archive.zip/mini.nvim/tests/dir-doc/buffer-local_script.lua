_G.is_inside_buffer_local_script = true

-- Buffer variable should be later restored
vim.b.minidoc_config = { script_path = 'aaa' }
