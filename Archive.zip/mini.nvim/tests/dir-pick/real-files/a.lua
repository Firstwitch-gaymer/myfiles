local a = 1
local t = {
  x = math.max(1, 2),
  y = math.min(1, 2),
}
