_G.plugin_log = _G.plugin_log or {}
table.insert(_G.plugin_log, 'plugin/subdir/plug_1_sub.lua')
