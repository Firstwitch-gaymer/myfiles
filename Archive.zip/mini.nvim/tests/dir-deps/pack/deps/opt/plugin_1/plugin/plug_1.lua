_G.plugin_log = _G.plugin_log or {}
table.insert(_G.plugin_log, 'plugin/plug_1.lua')
