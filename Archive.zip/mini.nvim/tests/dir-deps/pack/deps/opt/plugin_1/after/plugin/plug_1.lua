_G.plugin_log = _G.plugin_log or {}
table.insert(_G.plugin_log, 'after/plugin/plug_1.lua')
