_G.plugin_log = _G.plugin_log or {}
table.insert(_G.plugin_log, 'after/plugin/subdir/plug_1_sub.lua')
