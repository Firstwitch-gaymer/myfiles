local minitest = require('mini.test')

if _G.MiniTest == nil then minitest.setup() end
minitest.run()
