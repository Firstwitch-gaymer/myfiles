| init file          | median | mean   | stdev | minimum | maximum |
| ---                | ---    | ---    | ---   | ---     | ---     |
| starter-default    | 69.0ms | 70.8ms | 4.3ms | 63.6ms  | 82.7ms  |
| empty              | 64.1ms | 65.8ms | 4.3ms | 60.0ms  | 79.4ms  |
| startify-starter   | 70.2ms | 71.9ms | 4.5ms | 64.3ms  | 85.7ms  |
| startify-original  | 80.3ms | 82.2ms | 4.5ms | 76.4ms  | 107.2ms |
| startify-alpha     | 72.1ms | 73.8ms | 4.3ms | 66.5ms  | 86.9ms  |
| dashboard-starter  | 68.4ms | 70.3ms | 4.5ms | 63.3ms  | 102.9ms |
| dashboard-original | 70.6ms | 72.3ms | 4.4ms | 65.5ms  | 99.6ms  |
| dashboard-alpha    | 69.8ms | 71.5ms | 4.4ms | 64.7ms  | 97.2ms  |
