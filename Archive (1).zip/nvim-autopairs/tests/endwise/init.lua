local data1, data2
local function wind()

    vim.api.nvim_get_current_buf()
















end

