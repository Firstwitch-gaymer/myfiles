export default function Home() {
  return (
    <>
      <Button
        style={{ 
          color: 'blue', 
        }}
        disabled
      >
      </Button>
      <Button
        style={{
          color: 'blue',
        }}
      />
    </>
  )
}
