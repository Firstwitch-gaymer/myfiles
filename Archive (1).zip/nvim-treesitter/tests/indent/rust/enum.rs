enum Foo {
    X,
    Y(
        char,
        char,
    ),
    Z {
        x: u32,
        y: u32,
    },
}
