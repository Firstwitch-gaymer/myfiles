def foo(a,
        b,
        c):
    pass

def foobar(a,
