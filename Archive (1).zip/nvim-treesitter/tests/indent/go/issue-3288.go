package main

func correct(word string) {
	switch word {

	} // <---
	select {

	} // <---
}

func test() {
	cases := []struct {
		first, second string
	} {
		{"Hello", "World"},   
	}

	for range cases {
		println("random stuff")
	}
}
